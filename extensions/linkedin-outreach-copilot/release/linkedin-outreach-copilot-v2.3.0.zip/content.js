(function(){function e(){return window.location.pathname.includes(`/in/`)}function t(){let t=e(),n=window.location.href.split(`?`)[0].replace(/\/overlay\/.*$/,``).replace(/\/$/,``),r=[`h1.text-heading-xlarge`,`h1.inline.t-24`,`main section h1`,`.pv-text-details__left-panel h1`,`section.artdeco-card h1`,`div.ph5 h1`,`.pv-top-card--list li:first-child`,`main h1`,`h1`],i=``;for(let e of r){let t=document.querySelector(e)?.textContent?.trim();if(t&&t.length>1&&t.length<70&&!t.toLowerCase().includes(`search`)&&!t.toLowerCase().includes(`feed`)){i=t;break}}let a=``;if(document.title&&document.title.includes(`LinkedIn`)){let e=document.title.replace(/^\(\d+\)\s*/,``).replace(/\s*\|\s*LinkedIn.*$/i,``).trim();if(e.includes(` - `)){let t=e.split(` - `);i||=t[0].trim(),a=t.slice(1).join(` - `).trim()}else!i&&e&&(i=e)}if(!i&&!t)return null;let o=[`.text-body-medium.break-words`,`.pv-text-details__left-panel div.text-body-medium`,`div[data-generated-suggestion-target]`,`.pv-top-card-section__headline`,`section.artdeco-card .text-body-medium`,`div.ph5 .text-body-medium`],s=``;for(let e of o){let t=document.querySelector(e)?.textContent?.trim();if(t&&t.length>3){s=t;break}}s||=a||`Professional on LinkedIn`;let c=[`.text-body-small.inline.t-black--light.break-words`,`.pv-text-details__left-panel span.text-body-small`,`.pv-top-card-section__location`],l=``;for(let e of c){let t=document.querySelector(e)?.textContent?.trim();if(t){l=t;break}}let u=[`#about ~ .display-flex .inline-show-more-text`,`section[data-section="about"] .inline-show-more-text`,`#about ~ div .full-width span[aria-hidden="true"]`,`.pv-about-section .pv-about__summary-text`],d=``;for(let e of u){let t=document.querySelector(e)?.textContent?.trim();if(t){d=t;break}}let f=[`.pv-text-details__right-panel button span[aria-hidden="true"]`,`.pv-top-card--experience-list-item`,`#experience ~ .pvs-list__outer-container li:first-child span[aria-hidden="true"]`],p=``;for(let e of f){let t=document.querySelector(e)?.textContent?.trim();if(t){p=t;break}}if(!p&&s.includes(` at `)){let e=s.split(` at `);p=e[e.length-1].trim().split(`|`)[0].trim()}let m=document.querySelector(`img.pv-top-card-profile-picture__image, .presence-entity__image, img.evi-image`)?.src||``;return{name:i||`LinkedIn Member`,headline:s,location:l,company:p||``,about:d.slice(0,500),profileUrl:n,avatarUrl:m}}async function n(){let e=document.querySelector(`.artdeco-modal, .pv-profile-section__section-info`);if(!e){let t=document.querySelector(`a#top-card-text-details-contact-info, a[href*="/overlay/contact-info/"]`);if(!t)return{websites:[],privacyRestricted:!0};t.click();for(let t=0;t<15&&(await new Promise(e=>setTimeout(e,100)),e=document.querySelector(`.artdeco-modal, .pv-profile-section__section-info`),!e);t++);}let t=document.querySelector(`section.ci-email a.pv-contact-info__contact-link, .ci-email .pv-contact-info__contact-link, a[href^="mailto:"]`),n=t?.textContent?.trim()||t?.href?.replace(`mailto:`,``).trim(),r=document.querySelector(`section.ci-phone .pv-contact-info__ci-container span, .ci-phone ul li span`)?.textContent?.trim(),i=document.querySelector(`section.ci-twitter a, .ci-twitter a`)?.textContent?.trim(),a=document.querySelectorAll(`section.ci-websites a, .ci-websites a`),o=[];return a.forEach(e=>{e.href&&!o.includes(e.href)&&o.push(e.href)}),{email:n||void 0,phone:r||void 0,twitter:i||void 0,websites:o,privacyRestricted:!n&&!r}}var r={delve:`explore`,delves:`explores`,delving:`exploring`,delved:`explored`,tapestry:`mix`,camaraderie:`teamwork`,cacophony:`noise`,palpable:`clear`,intricate:`detailed`,vibrant:`active`,fleeting:`brief`,ignite:`spark`,ignites:`sparks`,igniting:`sparking`,unravel:`unpack`,unravels:`unpacks`,unraveling:`unpacking`,grapple:`deal`,grapples:`deals`,grappling:`dealing`,amidst:`in`,underscore:`highlight`,underscores:`highlights`,underscoring:`highlighting`,prioritize:`focus on`,prioritizes:`focuses on`,prioritizing:`focusing on`},i={leverage:`use`,leverages:`uses`,leveraging:`using`,leveraged:`used`,utilize:`use`,utilizes:`uses`,utilizing:`using`,utilized:`used`,facilitate:`help`,facilitates:`helps`,facilitating:`helping`,facilitated:`helped`,comprehensive:`complete`,robust:`solid`,seamless:`smooth`,seamlessly:`smoothly`,pivotal:`key`,foster:`build`,fosters:`builds`,fostering:`building`,fostered:`built`,meticulous:`careful`,meticulously:`carefully`,multifaceted:`varied`,transformative:`major`,groundbreaking:`new`,empower:`help`,empowers:`helps`,empowering:`helping`,empowered:`helped`,synergy:`alignment`,synergies:`alignment`,holistic:`thorough`,impactful:`effective`,landscape:`market`,revolutionize:`change`,revolutionizes:`changes`,revolutionizing:`changing`,harness:`use`,harnesses:`uses`,harnessing:`using`,unlock:`open`,unlocks:`opens`,unlocking:`opening`,elevate:`improve`,elevates:`improves`,elevating:`improving`,elevated:`improved`,showcase:`show`,showcases:`shows`,showcasing:`showing`,bolster:`strengthen`,bolsters:`strengthens`,bolstering:`strengthening`,testament:`proof`,enhance:`improve`,enhances:`improves`,enhancing:`improving`,enhanced:`improved`,supercharge:`accelerate`,unleash:`release`},a=[{pattern:/\b(?:in today's fast-paced (?:world|digital landscape|environment))\b/gi,replacement:`today`,name:`in today's fast-paced world`},{pattern:/\bit is (?:worth|important) to (?:note|remember|mention) that\s*/gi,replacement:``,name:`it is worth noting that`},{pattern:/\bit is crucial to (?:understand|recognize) that\s*/gi,replacement:``,name:`it is crucial to recognize that`},{pattern:/\bserves as a testament to\b/gi,replacement:`proves`,name:`serves as a testament to`},{pattern:/\bplays a (?:crucial|pivotal|vital|key) role in\b/gi,replacement:`directly drives`,name:`plays a crucial role in`},{pattern:/\bat the end of the day,?\s*/gi,replacement:``,name:`at the end of the day`},{pattern:/\bwithout further ado,?\s*/gi,replacement:``,name:`without further ado`}],o=[{pattern:/^[ \t]*Furthermore,?\s*/gim,replacement:`Plus, `,name:`Furthermore`},{pattern:/^[ \t]*Moreover,?\s*/gim,replacement:`Also, `,name:`Moreover`},{pattern:/^[ \t]*Additionally,?\s*/gim,replacement:`And `,name:`Additionally`},{pattern:/^[ \t]*In conclusion,?\s*/gim,replacement:`Bottom line: `,name:`In conclusion`},{pattern:/^[ \t]*To summarize,?\s*/gim,replacement:`In short: `,name:`To summarize`}];function s(e){return e.replace(/\s*—\s*/g,`, `).replace(/\s*--\s*/g,`, `).replace(/,\s*,/g,`,`)}function c(e){if(!e||!e.trim())return{isClean:!0,score:100,findings:[],cleanText:``};let t=e,n=[];(t.includes(`—`)||t.includes(`--`))&&(t=s(t),n.push({ruleId:`typography-em-dash`,category:`HOUSE_STYLE`,message:`Removed em dashes (—) in favor of natural punctuation cadence.`}));for(let e of a)e.pattern.test(t)&&(t=t.replace(e.pattern,e.replacement),n.push({ruleId:`empty-frame`,category:`REGISTER`,message:`Removed empty delay frame: "${e.name}".`}));for(let e of o)e.pattern.test(t)&&(t=t.replace(e.pattern,e.replacement),n.push({ruleId:`template-transition`,category:`REGISTER`,message:`Replaced decorative transition "${e.name}".`}));let c=t.split(/\b/),l=[];for(let e=0;e<c.length;e++){let t=c[e],a=t.toLowerCase();if(r[a]){let e=r[a],i=t[0]===t[0].toUpperCase()?e.charAt(0).toUpperCase()+e.slice(1):e;l.push(i),n.push({ruleId:`tier-1-vocabulary`,category:`RESEARCH_SIGNAL`,message:`Replaced model-excess word "${t}" with plain equivalent "${e}".`,span:t,replacement:e})}else if(i[a]){let e=i[a],r=t[0]===t[0].toUpperCase()?e.charAt(0).toUpperCase()+e.slice(1):e;l.push(r),n.push({ruleId:`tier-2-vocabulary`,category:`RESEARCH_SIGNAL`,message:`Replaced buzzword "${t}" with grounded verb "${e}".`,span:t,replacement:e})}else l.push(t)}t=l.join(``),t=t.replace(/[ \t]{2,}/g,` `),t=t.replace(/\s+([.,!?;:])/g,`$1`);let u=n.length*5,d=Math.max(70,Math.min(100,100-u));return{isClean:n.length===0,score:d,findings:n,cleanText:t.trim()}}function l(e){let t=(e||``).toLowerCase();return t.includes(`sale`)||t.includes(`growth`)||t.includes(`revenue`)||t.includes(`cro`)||t.includes(`sdr`)||t.includes(`bdr`)?`sales pipeline`:t.includes(`engineer`)||t.includes(`tech`)||t.includes(`cto`)||t.includes(`developer`)||t.includes(`software`)?`engineering stack`:t.includes(`product`)||t.includes(`cpo`)?`product roadmap`:t.includes(`operat`)||t.includes(`coo`)?`internal operations`:t.includes(`market`)||t.includes(`cmo`)||t.includes(`brand`)||t.includes(`demand`)?`customer acquisition`:t.includes(`recruit`)||t.includes(`talent`)||t.includes(`people`)||t.includes(`hr`)?`talent acquisition`:t.includes(`founder`)||t.includes(`ceo`)||t.includes(`president`)||t.includes(`co-founder`)||t.includes(`partner`)?`executive initiatives`:`team priorities`}function u(e,t,n,r){let i=t&&t!==`your team`&&t!==`Unknown`?t.trim():``;if(i)switch(n){case`sales pipeline`:return`${i}'s outbound pipeline & rep efficiency`;case`engineering stack`:return`Quick question re: ${i}'s tech stack`;case`product roadmap`:return`Idea for ${i}'s product roadmap`;case`internal operations`:return`Streamlining ${i}'s internal workflows`;case`customer acquisition`:return`${i}'s B2B customer acquisition`;case`talent acquisition`:return`${i}'s candidate pipeline & hiring`;case`executive initiatives`:return`${i}'s scaling milestones - quick thought`;default:return`${i}'s ${n} - quick inquiry`}return`${e} - quick question regarding ${r.split(` at `)[0].slice(0,26)}`}async function d(e,t){let n=e.name.split(` `)[0]||e.name,r=e.company||`your team`,i=e.headline.split(` at `)[0]||e.headline,a=[];if(t.aiProvider===`gemini`&&t.apiKey)try{a=await m(e,t,n,r,i)}catch(e){console.warn(`Gemini API call failed, falling back to smart heuristic generator:`,e)}else if(t.aiProvider===`openai`&&t.apiKey)try{a=await h(e,t,n,r,i)}catch(e){console.warn(`OpenAI API call failed, falling back to smart heuristic generator:`,e)}return a.length===0&&(a=p(n,r,i,e,t)),a.map(e=>({...e,message:c(e.message).cleanText}))}async function f(e,t){let n=e.name.split(` `)[0]||e.name,r=e.company&&e.company!==`Unknown`?e.company:`your team`,i=e.headline.split(` at `)[0]||e.headline,a=l(e.headline),o=t.customPitch||`automating high-touch outbound workflows and increasing reply rates`,s=null;if(t.aiProvider===`gemini`&&t.apiKey)try{let c=`You are an elite B2B outbound sales director who follows the "Not-Ai" editorial rules.
Not-Ai Rules: NO em dashes (—), NO buzzwords (delve, leverage, seamless, transformative, pivotal, "in today's world"). Use natural contractions.
Prospect: ${e.name} (First name: ${n})
Role: ${i} (Focus area: ${a})
Company: ${r}
Sender Offer: ${o}

Subject Line Requirements: Absolutely NO generic clickbait like "quick question" or "hello". Write a hyper-relevant subject line directly addressing their exact role and company (e.g. "${r}'s outbound pipeline & rep efficiency" or "Idea for ${r}'s ${a}").

Return JSON strictly with format:
{
  "touch1_linkedin_connect": "Connection note under 280 chars referencing their work",
  "touch2_linkedin_followup": "LinkedIn follow-up message 2 days after connect under 320 chars with peer question",
  "touch3_email_subject": "Contextual, relevant subject line under 6 words tailored to ${r} and ${a}",
  "touch3_email_body": "3-sentence personalized cold email under 80 words addressing ${a} pain points with a soft low-pressure CTA",
  "touch4_email_followup": "1-sentence polite bump email 4 days later"
}`,l=`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${t.apiKey}`,u=await fetch(l,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({contents:[{parts:[{text:c}]}],generationConfig:{responseMimeType:`application/json`}})});if(u.ok){let e=await u.json(),t=JSON.parse(e?.candidates?.[0]?.content?.parts?.[0]?.text);t.touch3_email_subject&&(s=t)}}catch(e){console.warn(`Sequence generation via Gemini failed, falling back to contextual generator:`,e)}if(!s){let e=u(n,r,a,i);s={touch1_linkedin_connect:`Hi ${n}, came across your work leading ${i.slice(0,32)} at ${r}. Really impressed by the team's trajectory! Would love to connect and follow your journey.`,touch2_linkedin_followup:`Hey ${n}, thanks for connecting! Quick question: how are you and the team at ${r} currently optimizing your ${a} workflows this quarter? Always love exchanging notes with peers in your space.`,touch3_email_subject:e,touch3_email_body:`Hi ${n},\n\nSaw you're steering ${i} at ${r}. When speaking with other leaders in ${a}, the biggest bottleneck right now is ${o}.\n\nWe helped similar teams eliminate 8+ hours of manual overhead per rep while increasing pipeline response rates by 40%.\n\nOpen to a brief 5-minute chat next Tuesday to see how ${r} compares?\n\nBest,\n[Your Name]`,touch4_email_followup:`Hi ${n}, wanted to quickly bump this in case it got buried. Any interest in exploring this for ${r}'s ${a}, or is this not a priority right now?`}}return{touch1_linkedin_connect:c(s.touch1_linkedin_connect).cleanText,touch2_linkedin_followup:c(s.touch2_linkedin_followup).cleanText,touch3_email_subject:c(s.touch3_email_subject).cleanText,touch3_email_body:c(s.touch3_email_body).cleanText,touch4_email_followup:c(s.touch4_email_followup).cleanText}}function p(e,t,n,r,i){let a=l(r.headline),o=i.customPitch?` We're currently helping teams like ${t} with ${i.customPitch}.`:``;return[{id:`hook_1`,tone:`casual`,label:`Casual Compliment`,message:`Hi ${e}, came across your profile while following leaders in ${a}. Really impressed by what you're building at ${t}! Would love to connect.`},{id:`hook_2`,tone:`value_focused`,label:`Role-Specific Value Angle`,message:`Hi ${e}, saw you're driving ${n} at ${t}.${o} Curious if optimizing your team's ${a} efficiency is a focus this quarter? Either way, happy to connect!`},{id:`hook_3`,tone:`curious`,label:`Peer Curiosity Hook`,message:`Hey ${e}, love ${t}'s approach to growth. Quick question: what's been your biggest priority around ${a} lately? Thought I'd reach out directly!`}]}async function m(e,t,n,r,i){let a=l(e.headline),o=`You are an elite B2B cold outreach expert. Write 3 distinct, high-converting LinkedIn connection request messages (under 280 characters each, no hashtags, no generic fluff, sounds natural and human, NO em dashes).
Target Profile:
- Name: ${e.name} (First name: ${n})
- Headline/Role: ${i} (Focus: ${a})
- Company: ${r}
- My Offer: ${t.customPitch||`B2B outreach automation`}

Return JSON array of 3 objects with structure:
[
  { "id": "hook_1", "tone": "casual", "label": "Casual Compliment", "message": "..." },
  { "id": "hook_2", "tone": "value_focused", "label": "Value Angle", "message": "..." },
  { "id": "hook_3", "tone": "curious", "label": "Peer Question", "message": "..." }
]`,s=`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${t.apiKey}`,c=await fetch(s,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({contents:[{parts:[{text:o}]}],generationConfig:{responseMimeType:`application/json`}})});if(!c.ok)throw Error(`Gemini API error: ${c.statusText}`);let u=(await c.json())?.candidates?.[0]?.content?.parts?.[0]?.text;return JSON.parse(u)}async function h(e,t,n,r,i){let a=l(e.headline),o=`You are an elite B2B cold outreach expert. Write 3 distinct, high-converting LinkedIn connection request messages (under 280 characters each, no hashtags, sounds natural, NO em dashes).
Target: ${e.name}, Role: ${i} (${a}), Company: ${r}.
Return JSON array with "id", "tone", "label", "message".`,s=await fetch(`https://api.openai.com/v1/chat/completions`,{method:`POST`,headers:{"Content-Type":`application/json`,Authorization:`Bearer ${t.apiKey}`},body:JSON.stringify({model:`gpt-4o-mini`,messages:[{role:`user`,content:o}],response_format:{type:`json_object`}})});if(!s.ok)throw Error(`OpenAI API error: ${s.statusText}`);let c=await s.json(),u=JSON.parse(c?.choices?.[0]?.message?.content);return Array.isArray(u)?u:u.hooks||[]}var g={aiProvider:`gemini`,dailyQuota:5,usedToday:0,lastResetDate:new Date().toISOString().split(`T`)[0],isPro:!1};async function _(){return new Promise(e=>{if(typeof chrome>`u`||!chrome.storage?.sync){let t=localStorage.getItem(`outreach_copilot_settings`);e(t?JSON.parse(t):g)}else chrome.storage.sync.get([`settings`],t=>{let n=t.settings||g,r=new Date().toISOString().split(`T`)[0];n.lastResetDate!==r&&(n.usedToday=0,n.lastResetDate=r,v(n)),e(n)})})}async function v(e){return new Promise(t=>{typeof chrome>`u`||!chrome.storage?.sync?(localStorage.setItem(`outreach_copilot_settings`,JSON.stringify(e)),t()):chrome.storage.sync.set({settings:e},()=>t())})}async function y(){return new Promise(e=>{if(typeof chrome>`u`||!chrome.storage?.local){let t=localStorage.getItem(`outreach_copilot_leads`);e(t?JSON.parse(t):[])}else chrome.storage.local.get([`savedLeads`],t=>{e(t.savedLeads||[])})})}async function b(e){let t=await y(),n={...e,id:`lead_`+Date.now(),savedAt:new Date().toISOString(),status:`saved`},r=t.findIndex(t=>t.profileUrl===e.profileUrl);return r>=0?t[r]={...t[r],...n}:t.unshift(n),new Promise(e=>{typeof chrome>`u`||!chrome.storage?.local?(localStorage.setItem(`outreach_copilot_leads`,JSON.stringify(t)),e(n)):chrome.storage.local.set({savedLeads:t},()=>e(n))})}async function x(e){if(!e)return{hasValidMX:!1,provider:`No Mail Server`,confidenceScore:0};try{let t=`https://dns.google/resolve?name=${encodeURIComponent(e)}&type=MX`,n=await fetch(t);if(!n.ok)throw Error(`DNS Query returned HTTP ${n.status}`);let r=(await n.json())?.Answer||[];if(r.length===0)return{hasValidMX:!1,provider:`No Mail Server`,confidenceScore:0};let i=r.map(e=>e.data||``).filter(Boolean)[0]||``,a=i.toLowerCase(),o=`Custom Server`,s=85;return a.includes(`google`)||a.includes(`l.google.com`)?(o=`Google Workspace`,s=95):a.includes(`outlook`)||a.includes(`protection.outlook.com`)?(o=`Microsoft 365`,s=95):a.includes(`mimecast`)?(o=`Mimecast`,s=90):(a.includes(`pphosted`)||a.includes(`proofpoint`))&&(o=`Proofpoint`,s=90),{hasValidMX:!0,provider:o,primaryServer:i,confidenceScore:s}}catch(e){return console.warn(`DNS MX verification failed, falling back:`,e),{hasValidMX:!0,provider:`Custom Server`,confidenceScore:70}}}function S(e,t,n){let r=(e||``).trim().replace(/['"]/g,``),i=(t||``).trim().replace(/['"]/g,``),a=(n||``).trim().toLowerCase(),o=[];if(a){let e=`"${r}" "@${a}" email OR contact`;o.push({id:`dork_work_email`,title:`Direct Corporate Email Search`,query:e,url:`https://www.google.com/search?q=${encodeURIComponent(e)}`,description:`Scans indexed web pages, conference attendees, and directory signatures at ${a}`,targetBadge:`WORK EMAIL`})}else if(i){let e=`"${r}" "${i}" email OR contact OR phone`;o.push({id:`dork_work_email`,title:`Company Email & Contact Lookup`,query:e,url:`https://www.google.com/search?q=${encodeURIComponent(e)}`,description:`Scans for public email listings and direct contact details associated with ${i}`,targetBadge:`EMAIL / PHONE`})}else{let e=`"${r}" email OR contact OR "get in touch"`;o.push({id:`dork_work_email`,title:`Public Contact Search`,query:e,url:`https://www.google.com/search?q=${encodeURIComponent(e)}`,description:`Scans public web footprints and indexed contact cards`,targetBadge:`PUBLIC CONTACT`})}let s=i||a;if(s){let e=`"${r}" "${s}" filetype:pdf email OR phone`;o.push({id:`dork_pdf_filings`,title:`Published PDFs & SEC Filings`,query:e,url:`https://www.google.com/search?q=${encodeURIComponent(e)}`,description:`Discovers speaker decks, board disclosures, whitepapers, and published press packets`,targetBadge:`PDFs & DECKS`})}if(a){let e=`site:${a} "${r}" email OR phone OR contact`;o.push({id:`dork_staff_directory`,title:`Official Website Staff Directory`,query:e,url:`https://www.google.com/search?q=${encodeURIComponent(e)}`,description:`Direct deep search on ${a} for about/team/leadership bio pages`,targetBadge:`STAFF DIRECTORY`})}else if(i){let e=`site:linkedin.com/in "${r}" "${i}" contact`;o.push({id:`dork_staff_directory`,title:`Public LinkedIn Profile Index`,query:e,url:`https://www.google.com/search?q=${encodeURIComponent(e)}`,description:`Locates cached Google search index for ${r}'s profile data`,targetBadge:`CACHED PROFILE`})}let c=i?`site:x.com "${r}" "${i}"`:`site:x.com "${r}"`;o.push({id:`dork_twitter_profile`,title:`Verified X / Twitter Handle`,query:c,url:`https://www.google.com/search?q=${encodeURIComponent(c)}`,description:`Finds verified personal Twitter/X handles for fast social outreach and direct messages`,targetBadge:`X / TWITTER`});let l=i?`"${r}" "${i}" ("@gmail.com" OR "@outlook.com")`:`"${r}" ("@gmail.com" OR "@outlook.com")`;return o.push({id:`dork_personal_email`,title:`Personal Email & Secondary Accounts`,query:l,url:`https://www.google.com/search?q=${encodeURIComponent(l)}`,description:`Uncovers personal email addresses listed on newsletters, open-source repos, and blogs`,targetBadge:`PERSONAL EMAIL`}),o}function C(e){window.open(e,`_blank`)}function w(e){if(!e)return``;let t=e.toLowerCase();t=t.split(`|`)[0].split(`-`)[0].split(`,`)[0].trim(),t=t.replace(/\b(inc|llc|ltd|corp|corporation|group|technologies|solutions|holdings|company|co)\b/gi,``).trim(),t=t.replace(/[^a-z0-9\s]/g,``);let n=t.split(/\s+/)[0];return n?`${n}.com`:``}async function T(e,t,r=!1){let i=w(e.company||``),a=e.name.trim().split(/\s+/),o=(a[0]||``).toLowerCase().replace(/[^a-z]/g,``),s=(a[a.length-1]||``).toLowerCase().replace(/[^a-z]/g,``),c=i&&o?s?`${o}.${s}@${i}`:`${o}@${i}`:void 0,l=S(e.name,e.company||``,i),u;if(i)try{u=await x(i)}catch(e){console.warn(`MX lookup failed:`,e)}if(r)try{let e=await n();if(e.email||e.phone)return{email:e.email||c,phone:e.phone,confidence:`verified_linkedin`,domain:i,mxRecord:u,osintDorks:l,deliverabilityGrade:`100% (LinkedIn Verified)`,sourceNote:`Directly verified from LinkedIn Contact Info`}}catch(e){console.warn(`Modal scrape error:`,e)}if(c){let e=u?.hasValidMX?u.provider:`Active Domain`,t=u?.confidenceScore||85;return{email:c,phone:void 0,confidence:`pattern_guess`,domain:i,mxRecord:u,osintDorks:l,deliverabilityGrade:`${t}% Deliverable (${e})`,sourceNote:`Calculated from ${e} MX records`}}return{confidence:`not_found`,domain:i,mxRecord:u,osintDorks:l,sourceNote:`Not publicly listed on profile`}}async function E(e,t){let n=(e||`Scaling outbound sales workflows without hiring more reps`).trim();if(t.aiProvider===`gemini`&&t.apiKey)try{let e=`You are a viral LinkedIn creator who writes using the "Not-Ai" editorial method.
Rules from Not-Ai:
1. Absolutely NO em dashes (—). Use commas or hyphens.
2. Absolutely NO buzzwords: delve, leverage, utilize, seamless, pivotal, transformative, groundbreaking, tapestry, vibrant, "in today's fast-paced world", "it is worth noting".
3. Write with high scannability: 1-2 short sentences per paragraph with blank lines between paragraphs.
4. Use first-person naturally with real contractions (I've, we're, don't).
5. Ground claims in real observations, not generic cheerleading.

Input Topic/Notes: "${n}"

Generate JSON with 3 distinct posts:
{
  "story": "Story-driven post starting with a concrete event, tension, resolution, and takeaway.",
  "framework": "Step-by-step actionable framework with clear bullet points and actionable advice.",
  "contrarian": "A contrarian observation that challenges common industry misconceptions respectfully."
}`,r=`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${t.apiKey}`,i=await fetch(r,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({contents:[{parts:[{text:e}]}],generationConfig:{responseMimeType:`application/json`}})});if(i.ok){let e=await i.json(),t=JSON.parse(e?.candidates?.[0]?.content?.parts?.[0]?.text);if(t.story&&t.framework)return[O(`post_1`,`story`,`📖 Story & Lesson`,t.story),O(`post_2`,`framework`,`⚡ Actionable Playbook`,t.framework),O(`post_3`,`contrarian`,`💡 Contrarian Truth`,t.contrarian)]}}catch(e){console.warn(`Gemini post generation failed, falling back to Not-Ai smart templates:`,e)}return[O(`post_1`,`story`,`📖 Story & Lesson`,`Most teams think scaling outreach means buying more contact lists.\n\nThree weeks ago, we tested this assumption directly on ${n}.\n\nInstead of blasting 500 cold templates, we sent 40 highly specific, one-line notes referencing published company projects.\n\nThe outcome:\n• 18 connection acceptances (45% rate)\n• 9 substantive conversations started\n• 3 qualified pipeline calls booked\n\nHigh volume hides bad targeting. A single relevant line beats three paragraphs of polished generic copy every single time.\n\nWhat has been your team's experience with outreach volume vs personalization this quarter?`),O(`post_2`,`framework`,`⚡ Actionable Playbook`,`Here is a simple framework we use for ${n}:\n\n1. Find verified triggers first\nLook for job changes, SEC filings, or recent engineering blog updates before drafting a single word.\n\n2. Cut the first two sentences\nDelete "hope this finds you well" and "my name is X". Lead immediately with the problem you solve.\n\n3. Use low-friction CTAs\nNever ask for 30 minutes on a first touch. Ask for their perspective on a 1-sentence hypothesis.\n\n4. Follow up on LinkedIn after email\nMulti-channel touchpoints double response rates when spaced 48 hours apart.\n\nKeep it simple. Eliminate friction.`),O(`post_3`,`contrarian`,`💡 Contrarian Truth`,`Unpopular opinion about ${n}:\n\nMost outbound sequences fail because they sound like an AI wrote them.\n\nWhen a prospect sees phrases like "in today's digital landscape" or "delve into your workflow", their brain instantly marks it as spam.\n\nThe highest-converting messages in 2026 look like a quick note typed from a phone by a peer who actually knows their market.\n\nDrop the corporate jargon. Speak like a human with real data.\n\nCurious: what is the worst outreach cliché in your inbox right now?`)]}async function D(e,t){let n=(e||`Sharing thoughts on pipeline growth and outbound sales strategy`).trim().slice(0,500);if(t.aiProvider===`gemini`&&t.apiKey)try{let e=`You are a senior executive leaving a high-value, authentic comment on a LinkedIn post.
Post snippet to comment on: "${n}"

Rules from Not-Ai:
1. No em dashes (—).
2. No generic filler ("Great post!", "Thanks for sharing!", "100% agree!", "So inspiring!").
3. Keep it 2 to 4 sentences max.
4. Add genuine substance, a peer tradeoff, or a thoughtful question.

Generate JSON with 3 comments:
{
  "insight": "Adds a specific peer observation or real-world tradeoff to their point.",
  "question": "Asks an insightful follow-up question on how they handle edge cases.",
  "perspective": "Offers a respectful alternative angle or constraint based on experience."
}`,r=`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${t.apiKey}`,i=await fetch(r,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({contents:[{parts:[{text:e}]}],generationConfig:{responseMimeType:`application/json`}})});if(i.ok){let e=await i.json(),t=JSON.parse(e?.candidates?.[0]?.content?.parts?.[0]?.text);if(t.insight&&t.question)return[k(`comm_1`,`insight`,`💡 Peer Value-Add`,t.insight),k(`comm_2`,`question`,`❓ Thoughtful Question`,t.question),k(`comm_3`,`perspective`,`⚖️ Nuanced Perspective`,t.perspective)]}}catch(e){console.warn(`Gemini comment generation failed, using Not-Ai heuristic templates:`,e)}return[k(`comm_1`,`insight`,`💡 Peer Value-Add`,`Spot on observation. We saw the exact same pattern when testing this: cutting the ceremonial preamble cut drop-off by nearly half. Focusing strictly on the primary bottleneck gives prospects a reason to reply.`),k(`comm_2`,`question`,`❓ Thoughtful Question`,`Really interesting takeaway here. How do you and your team balance this when dealing with enterprise accounts that have multiple decision-makers across engineering and procurement?`),k(`comm_3`,`perspective`,`⚖️ Nuanced Perspective`,`Great breakdown. One nuance we noticed is that timing often matters more than channel: reaching someone within 48 hours of an announced initiative consistently outperforms cold outbound regardless of pitch length.`)]}function O(e,t,n,r){let i=c(r);return{id:e,style:t,title:n,content:i.cleanText,notAiScore:i.score}}function k(e,t,n,r){let i=c(r);return{id:e,type:t,label:n,content:i.cleanText,notAiScore:i.score}}(function(){console.log(`⚡ LinkedIn Outreach Copilot + Not-Ai Humanizer initializing...`);let e=`outreach-copilot-root-host`;if(document.getElementById(e))return;let n=!1,r=`sequence`,i=null,a=``,o=null,s=[],c=null,u=null,p=!1,m=!1,h=0,g=``,v=[],y=!1,x=``,S=[],w=!1;_().then(e=>{u=e});let O=document.createElement(`div`);O.id=e,O.style.all=`initial`,O.style.position=`fixed`,O.style.zIndex=`2147483647`,O.style.top=`0`,O.style.left=`0`,O.style.width=`0`,O.style.height=`0`,O.style.overflow=`visible`;let k=O.attachShadow({mode:`open`}),A=document.createElement(`style`);A.textContent=`
    * {
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }

    /* Stable Floating Launcher Button - Royal Navy */
    .copilot-launcher {
      position: fixed;
      bottom: 24px;
      right: 24px;
      display: flex;
      align-items: center;
      gap: 10px;
      background: linear-gradient(135deg, #0b192c 0%, #1e3e62 100%);
      color: #ffffff;
      padding: 12px 22px;
      border-radius: 9999px;
      border: 2px solid rgba(56, 189, 248, 0.45);
      box-shadow: 0 12px 28px -4px rgba(11, 25, 44, 0.65), 0 4px 8px -2px rgba(0, 0, 0, 0.3);
      cursor: pointer;
      font-weight: 700;
      font-size: 14px;
      user-select: none;
      z-index: 2147483647;
      transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .copilot-launcher:hover {
      transform: translateY(-2px) scale(1.03);
      box-shadow: 0 16px 32px -4px rgba(11, 25, 44, 0.75), 0 0 16px rgba(56, 189, 248, 0.4);
    }
    .copilot-badge-dot {
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: #fbbf24;
      box-shadow: 0 0 8px #fbbf24;
    }

    /* Apollo-style Docked Drawer - Royal Navy */
    .copilot-drawer {
      position: fixed;
      top: 64px;
      right: 24px;
      width: 440px;
      max-height: calc(100vh - 84px);
      background: #ffffff;
      border-radius: 16px;
      border: 1px solid rgba(30, 62, 98, 0.2);
      box-shadow: 0 25px 50px -12px rgba(11, 25, 44, 0.4), 0 0 0 1px rgba(11, 25, 44, 0.08);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      z-index: 2147483647;
      animation: copilotFadeIn 0.15s ease-out;
    }

    @keyframes copilotFadeIn {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .copilot-header {
      padding: 14px 18px;
      background: linear-gradient(135deg, #0b192c 0%, #1e3e62 100%);
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid rgba(56, 189, 248, 0.25);
    }
    .copilot-title {
      font-weight: 700;
      font-size: 15px;
      display: flex;
      align-items: center;
      gap: 8px;
      color: #ffffff;
    }
    .copilot-title-badge {
      background: rgba(56, 189, 248, 0.2);
      color: #38bdf8;
      border: 1px solid rgba(56, 189, 248, 0.4);
      font-size: 10px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .copilot-close-btn {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #ffffff;
      font-size: 16px;
      cursor: pointer;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0.9;
      transition: background 0.15s;
    }
    .copilot-close-btn:hover {
      background: rgba(255, 255, 255, 0.25);
      opacity: 1;
    }

    .copilot-profile-box {
      padding: 12px 18px;
      background: #f8fafc;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .copilot-avatar {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      background: linear-gradient(135deg, #0b192c 0%, #1e3e62 100%);
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 18px;
      object-fit: cover;
      flex-shrink: 0;
      border: 2px solid #38bdf8;
    }
    .copilot-profile-info {
      flex: 1;
      min-width: 0;
    }
    .copilot-prospect-name {
      font-weight: 700;
      font-size: 15px;
      color: #0b192c;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .copilot-prospect-role {
      font-size: 12px;
      color: #475569;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-top: 2px;
    }
    .copilot-prospect-company {
      font-size: 11px;
      color: #1e3e62;
      font-weight: 700;
      margin-top: 2px;
      display: flex;
      align-items: center;
      gap: 4px;
    }

    /* Contact Details Card */
    .copilot-contact-card {
      margin: 10px 18px 0;
      padding: 12px;
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      border-radius: 10px;
    }
    .copilot-contact-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }
    .copilot-contact-title {
      font-size: 11px;
      font-weight: 800;
      color: #0b192c;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .copilot-badge-verified {
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 4px;
      font-weight: 700;
      background: #dcfce7;
      color: #15803d;
      border: 1px solid #86efac;
    }
    .copilot-badge-mx {
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 4px;
      font-weight: 700;
      background: #e0f2fe;
      color: #0369a1;
      border: 1px solid #7dd3fc;
    }
    .copilot-contact-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 0;
      border-bottom: 1px dashed #e2e8f0;
      font-size: 12px;
    }
    .copilot-contact-row:last-child {
      border-bottom: none;
    }
    .copilot-contact-val {
      font-weight: 600;
      color: #0b192c;
      display: flex;
      align-items: center;
      gap: 6px;
      word-break: break-all;
    }
    .copilot-contact-empty {
      font-weight: 500;
      color: #94a3b8;
      font-style: italic;
    }
    .copilot-contact-copy-btn {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      color: #1e3e62;
      padding: 3px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      flex-shrink: 0;
      margin-left: 8px;
      transition: background 0.1s;
    }
    .copilot-contact-copy-btn:hover {
      background: #e2e8f0;
    }

    /* Buttons inside Contact Card */
    .copilot-contact-actions {
      display: flex;
      gap: 6px;
      margin-top: 10px;
    }
    .copilot-extract-btn {
      flex: 1;
      padding: 7px 10px;
      background: #ffffff;
      border: 1px solid #1e3e62;
      color: #1e3e62;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      transition: background 0.15s;
    }
    .copilot-extract-btn:hover {
      background: #f1f5f9;
    }
    .copilot-osint-quick-btn {
      flex: 1;
      padding: 7px 10px;
      background: linear-gradient(135deg, #0b192c 0%, #1e3e62 100%);
      border: 1px solid #0b192c;
      color: #ffffff;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      box-shadow: 0 2px 4px rgba(11, 25, 44, 0.2);
    }
    .copilot-osint-quick-btn:hover {
      background: linear-gradient(135deg, #07101e 0%, #142b45 100%);
    }

    /* Tabs - Royal Navy */
    .copilot-tabs {
      display: flex;
      background: #f1f5f9;
      border-bottom: 1px solid #e2e8f0;
      margin-top: 10px;
      overflow-x: auto;
    }
    .copilot-tab {
      flex: 1;
      min-width: 72px;
      padding: 9px 4px;
      background: none;
      border: none;
      font-size: 11px;
      font-weight: 600;
      color: #64748b;
      cursor: pointer;
      text-align: center;
      border-bottom: 2px solid transparent;
      transition: all 0.15s;
      white-space: nowrap;
    }
    .copilot-tab.active {
      color: #0b192c;
      border-bottom: 3px solid #1e3e62;
      background: #ffffff;
      font-weight: 700;
    }

    /* Actions Bar */
    .copilot-actions {
      padding: 10px 18px;
      display: flex;
      gap: 8px;
      border-bottom: 1px solid #f1f5f9;
    }
    .copilot-btn-primary {
      flex: 1;
      background: linear-gradient(135deg, #0b192c 0%, #1e3e62 100%);
      color: #ffffff;
      border: none;
      padding: 10px 14px;
      border-radius: 8px;
      font-weight: 700;
      font-size: 13px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      box-shadow: 0 4px 12px rgba(11, 25, 44, 0.25);
      transition: background 0.15s, transform 0.1s;
    }
    .copilot-btn-primary:hover {
      background: linear-gradient(135deg, #07101e 0%, #142b45 100%);
      transform: translateY(-1px);
    }
    .copilot-btn-secondary {
      background: #ffffff;
      color: #1e3e62;
      border: 1px solid #cbd5e1;
      padding: 10px 14px;
      border-radius: 8px;
      font-weight: 700;
      font-size: 13px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: background 0.15s;
    }
    .copilot-btn-secondary:hover {
      background: #f1f5f9;
    }
    .copilot-btn-saved {
      background: #16a34a !important;
      color: #ffffff !important;
      border-color: #16a34a !important;
    }

    /* Content Area */
    .copilot-body {
      padding: 14px 18px;
      flex: 1;
      overflow-y: auto;
      max-height: 310px;
    }

    .copilot-sequence-step {
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
      margin-bottom: 10px;
      background: #ffffff;
      box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }
    .copilot-step-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 6px;
    }
    .copilot-step-tag {
      font-size: 10px;
      font-weight: 800;
      text-transform: uppercase;
      color: #0b192c;
      background: #e0f2fe;
      border: 1px solid #bae6fd;
      padding: 2px 6px;
      border-radius: 4px;
      letter-spacing: 0.03em;
    }
    .copilot-notai-badge {
      font-size: 9px;
      font-weight: 800;
      color: #166534;
      background: #dcfce7;
      border: 1px solid #86efac;
      padding: 1px 5px;
      border-radius: 3px;
    }
    .copilot-step-btns {
      display: flex;
      gap: 6px;
    }
    .copilot-step-btn {
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      color: #1e3e62;
      padding: 3px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
    }
    .copilot-step-btn:hover {
      background: #e2e8f0;
    }
    .copilot-gmail-btn {
      background: #ea4335 !important;
      color: #ffffff !important;
      border-color: #ea4335 !important;
    }
    .copilot-step-text {
      margin: 0;
      font-size: 12px;
      color: #334155;
      line-height: 1.45;
      white-space: pre-wrap;
    }

    /* Step 3 Subject Line Box */
    .copilot-subject-box {
      background: #f1f5f9;
      border-left: 3px solid #1e3e62;
      padding: 6px 8px;
      margin-bottom: 6px;
      border-radius: 0 4px 4px 0;
    }
    .copilot-subject-label {
      font-size: 10px;
      font-weight: 800;
      color: #1e3e62;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .copilot-subject-text {
      font-weight: 700;
      font-size: 12px;
      color: #0b192c;
      margin-top: 2px;
    }
    .copilot-subject-chips {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
      margin-top: 6px;
    }
    .copilot-subject-chip {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 4px;
      cursor: pointer;
      color: #334155;
      font-weight: 600;
    }
    .copilot-subject-chip.active {
      background: #1e3e62;
      color: #ffffff;
      border-color: #0b192c;
    }

    /* Not-Ai Post & Comment Elements */
    .copilot-input-field {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      font-size: 12px;
      margin-bottom: 8px;
      box-sizing: border-box;
      resize: vertical;
    }
    .copilot-insert-btn {
      background: linear-gradient(135deg, #0b192c 0%, #1e3e62 100%);
      color: #ffffff;
      border: none;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
    }
    .copilot-insert-btn:hover {
      background: linear-gradient(135deg, #07101e 0%, #142b45 100%);
    }

    /* OSINT Dork Card */
    .copilot-dork-card {
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 10px 12px;
      margin-bottom: 10px;
      background: #ffffff;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .copilot-dork-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 4px;
    }
    .copilot-dork-title {
      font-weight: 700;
      font-size: 12px;
      color: #0b192c;
    }
    .copilot-dork-badge {
      font-size: 9px;
      font-weight: 800;
      padding: 1px 5px;
      border-radius: 3px;
      background: #f1f5f9;
      color: #1e3e62;
      border: 1px solid #cbd5e1;
    }
    .copilot-dork-desc {
      font-size: 11px;
      color: #64748b;
      margin: 2px 0 6px;
      line-height: 1.35;
    }
    .copilot-dork-query-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 4px;
      padding: 5px 8px;
      font-family: monospace;
      font-size: 10px;
      color: #0b192c;
      word-break: break-all;
      margin-bottom: 8px;
    }
    .copilot-dork-actions {
      display: flex;
      gap: 6px;
    }
    .copilot-dork-btn {
      background: linear-gradient(135deg, #0b192c 0%, #1e3e62 100%);
      color: #ffffff;
      border: none;
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    .copilot-dork-btn:hover {
      background: linear-gradient(135deg, #07101e 0%, #142b45 100%);
    }
    .copilot-dork-copy-btn {
      background: #ffffff;
      color: #1e3e62;
      border: 1px solid #cbd5e1;
      padding: 5px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
    }
    .copilot-dork-copy-btn:hover {
      background: #f1f5f9;
    }

    .copilot-footer {
      padding: 8px 18px;
      border-top: 1px solid #f1f3f5;
      background: #f8fafc;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 11px;
      color: #64748b;
    }
  `,k.appendChild(A);let j=document.createElement(`div`);j.id=`copilot-shadow-wrapper`,k.appendChild(j);function M(e){return e.replace(/\/overlay\/.*$/,``).replace(/\/$/,``)}function N(e,t){let n=e.name.split(` `)[0]||e.name,r=e.company&&e.company!==`Unknown`?e.company:``,i=l(e.headline);return r?[t?.touch3_email_subject||`${r}'s outbound pipeline & rep efficiency`,`${n} - quick question re: ${r}`,`Idea for ${r}'s ${i}`]:[t?.touch3_email_subject||`${n} - quick thought on ${e.headline.slice(0,24)}`,`${n} - 5-min chat regarding ${i}`,`Quick question for ${n}`]}function P(){j.innerHTML=`
      <div class="copilot-launcher" id="copilot-launch-btn">
        <span>⚡</span>
        <span>Outreach Copilot</span>
        ${i?`<div class="copilot-badge-dot" title="Profile detected"></div>`:``}
      </div>
    `,j.querySelector(`#copilot-launch-btn`)?.addEventListener(`click`,()=>{n=!0,B(),F()})}function F(){let e=i||t();if(!e){j.innerHTML=`
        <div class="copilot-drawer">
          <div class="copilot-header">
            <div class="copilot-title">
              <span>⚡</span>
              <span>Outreach Copilot</span>
              <span class="copilot-title-badge">Not-Ai Powered</span>
            </div>
            <button class="copilot-close-btn" id="copilot-close-btn">✕</button>
          </div>
          <div style="padding: 24px; text-align: center; color: #475569;">
            <div style="font-size: 32px; margin-bottom: 8px;">👤</div>
            <div style="font-weight: 700; font-size: 15px; margin-bottom: 6px; color: #0b192c;">No Profile Detected</div>
            <p style="font-size: 13px; color: #64748b; line-height: 1.5; margin: 0 0 16px;">
              Open any LinkedIn profile page or use the Not-Ai Post & Comment tools below:
            </p>
            <div style="display: flex; gap: 8px; justify-content: center;">
              <button class="copilot-tab" id="open-posts-standalone" style="background: #1e3e62; color: #fff; border-radius: 6px; padding: 8px 12px; font-weight: 700;">
                ✍️ Write a Post
              </button>
              <button class="copilot-tab" id="open-comments-standalone" style="background: #ffffff; border: 1px solid #cbd5e1; color: #1e3e62; border-radius: 6px; padding: 8px 12px; font-weight: 700;">
                💬 Smart Comment
              </button>
            </div>
          </div>
          <div class="copilot-footer">
            <span>Free Engine: DNS/MX + Not-Ai Skills</span>
            <span style="font-weight: 700; color: #1e3e62;">v2.3 Pro</span>
          </div>
        </div>
      `,j.querySelector(`#copilot-close-btn`)?.addEventListener(`click`,()=>{n=!1,P()}),j.querySelector(`#open-posts-standalone`)?.addEventListener(`click`,()=>{r=`posts`,F()}),j.querySelector(`#open-comments-standalone`)?.addEventListener(`click`,()=>{r=`comments`,F()});return}let a=c,l=o,O=N(e,l),k=O[h]||l?.touch3_email_subject||O[0];j.innerHTML=`
      <div class="copilot-drawer">
        <!-- Header -->
        <div class="copilot-header">
          <div class="copilot-title">
            <span>⚡</span>
            <span>Outreach Copilot</span>
            <span class="copilot-title-badge">Not-Ai Skills</span>
          </div>
          <button class="copilot-close-btn" id="copilot-close-btn" title="Close panel">✕</button>
        </div>

        <!-- Profile Top Card -->
        <div class="copilot-profile-box">
          ${e.avatarUrl?`<img src="${e.avatarUrl}" class="copilot-avatar" alt="${e.name}"/>`:`<div class="copilot-avatar">${(e.name[0]||`U`).toUpperCase()}</div>`}
          <div class="copilot-profile-info">
            <div class="copilot-prospect-name">${e.name}</div>
            <div class="copilot-prospect-role">${e.headline||`Professional on LinkedIn`}</div>
            ${e.company?`<div class="copilot-prospect-company">🏢 ${e.company}</div>`:``}
          </div>
        </div>

        <!-- Contact Intelligence (Method A & B) -->
        <div class="copilot-contact-card">
          <div class="copilot-contact-header">
            <div class="copilot-contact-title">🎯 Contact Intelligence</div>
            ${a?.confidence===`verified_linkedin`?`<span class="copilot-badge-verified">✓ LINKEDIN VERIFIED</span>`:a?.mxRecord?.hasValidMX?`<span class="copilot-badge-mx">✓ MX: ${a.mxRecord.provider}</span>`:`<span class="copilot-badge-mx">⚡ DOMAIN PATTERN</span>`}
          </div>

          <!-- Email Row -->
          <div class="copilot-contact-row">
            <div class="copilot-contact-val">
              <span>📧</span>
              ${a?.email?`<span id="contact-email-val">${a.email}</span>`:`<span class="copilot-contact-empty">Not detected yet</span>`}
            </div>
            ${a?.email?`<button class="copilot-contact-copy-btn" id="copy-email-btn">Copy</button>`:``}
          </div>

          <!-- Phone Row -->
          <div class="copilot-contact-row">
            <div class="copilot-contact-val">
              <span>📞</span>
              ${a?.phone?`<span id="contact-phone-val">${a.phone}</span>`:`<span class="copilot-contact-empty">Not publicly listed</span>`}
            </div>
            ${a?.phone?`<button class="copilot-contact-copy-btn" id="copy-phone-btn">Copy</button>`:``}
          </div>

          <!-- Contact Dual Action Buttons -->
          <div class="copilot-contact-actions">
            <button class="copilot-extract-btn" id="extract-modal-btn" title="Inspect native LinkedIn contact modal without closing it">
              ${m?`⏳ Checking Modal...`:`🔍 Reveal Public Info`}
            </button>
            <button class="copilot-osint-quick-btn" id="quick-osint-btn" title="Launch 1-Click Google Search for published emails and PDFs">
              🔎 Google OSINT Search
            </button>
          </div>
        </div>

        <!-- Navigation Tabs: Sequence, Not-Ai Posts, Not-Ai Comments, Google OSINT, Hooks -->
        <div class="copilot-tabs">
          <button class="copilot-tab ${r===`sequence`?`active`:``}" id="tab-sequence">
            🚀 Outreach
          </button>
          <button class="copilot-tab ${r===`posts`?`active`:``}" id="tab-posts">
            ✍️ Post Drafter
          </button>
          <button class="copilot-tab ${r===`comments`?`active`:``}" id="tab-comments">
            💬 Commenter
          </button>
          <button class="copilot-tab ${r===`osint`?`active`:``}" id="tab-osint">
            🔎 OSINT (${a?.osintDorks?.length||5})
          </button>
          <button class="copilot-tab ${r===`icebreakers`?`active`:``}" id="tab-icebreakers">
            ✨ Hooks
          </button>
        </div>

        ${r===`sequence`?`
          <!-- Action Bar for Sequence -->
          <div class="copilot-actions">
            <button class="copilot-btn-primary" id="copilot-generate-btn">
              ${p?`<span>⏳</span> Crafting Sequence...`:`<span>⚡</span> Generate Sequence`}
            </button>
            <button class="copilot-btn-secondary" id="copilot-save-btn">
              <span>💾</span> Save Lead
            </button>
          </div>
        `:``}

        <!-- Body Content -->
        <div class="copilot-body">
          ${r===`sequence`?l?`
                <!-- Touch 1: LinkedIn Connect -->
                <div class="copilot-sequence-step">
                  <div class="copilot-step-header">
                    <span class="copilot-step-tag">Step 1: LinkedIn Connect Note</span>
                    <span class="copilot-notai-badge">✓ Not-Ai Humanized</span>
                    <div class="copilot-step-btns">
                      <button class="copilot-step-btn" id="copy-touch1">Copy & Insert</button>
                    </div>
                  </div>
                  <p class="copilot-step-text">${l.touch1_linkedin_connect}</p>
                </div>

                <!-- Touch 2: LinkedIn Followup -->
                <div class="copilot-sequence-step">
                  <div class="copilot-step-header">
                    <span class="copilot-step-tag">Step 2: Follow-Up (+2 Days)</span>
                    <div class="copilot-step-btns">
                      <button class="copilot-step-btn" id="copy-touch2">Copy</button>
                    </div>
                  </div>
                  <p class="copilot-step-text">${l.touch2_linkedin_followup}</p>
                </div>

                <!-- Touch 3: Cold Email Pitch (Role-Targeted Subject) -->
                <div class="copilot-sequence-step">
                  <div class="copilot-step-header">
                    <span class="copilot-step-tag">Step 3: Direct Email (+4 Days)</span>
                    <div class="copilot-step-btns">
                      <button class="copilot-step-btn copilot-gmail-btn" id="gmail-touch3">✉️ Open in Gmail</button>
                      <button class="copilot-step-btn" id="copy-touch3">Copy</button>
                    </div>
                  </div>
                  
                  <!-- Dynamic Relevant Subject Line with Quick Selector -->
                  <div class="copilot-subject-box">
                    <div class="copilot-subject-label">Relevant Subject Line:</div>
                    <div class="copilot-subject-text">${k}</div>
                    <div class="copilot-subject-chips">
                      ${O.map((e,t)=>`
                        <button class="copilot-subject-chip ${t===h?`active`:``}" data-idx="${t}">
                          ${t===0?`🎯 Executive`:t===1?`⚡ Direct`:`💡 Collaborative`}
                        </button>
                      `).join(``)}
                    </div>
                  </div>

                  <p class="copilot-step-text">${l.touch3_email_body}</p>
                </div>

                <!-- Touch 4: Final Bump -->
                <div class="copilot-sequence-step">
                  <div class="copilot-step-header">
                    <span class="copilot-step-tag">Step 4: Final Follow-Up Bump</span>
                    <div class="copilot-step-btns">
                      <button class="copilot-step-btn" id="copy-touch4">Copy</button>
                    </div>
                  </div>
                  <p class="copilot-step-text">${l.touch4_email_followup}</p>
                </div>
              `:`
                <div style="text-align: center; padding: 24px 12px; color: #94a3b8;">
                  <div style="font-size: 32px; margin-bottom: 6px;">🚀</div>
                  <div style="font-weight: 700; font-size: 14px; color: #0b192c; margin-bottom: 4px;">Multi-Channel Sequence</div>
                  <p style="margin: 0; font-size: 12px; color: #64748b; line-height: 1.4;">
                    Click <b>"Generate Sequence"</b> to create an enterprise 4-step LinkedIn & Cold Email sequence tailored specifically to <b>${e.name}</b>.
                  </p>
                </div>
              `:r===`posts`?`
                <!-- Not-Ai Post Drafter -->
                <div style="margin-bottom: 12px;">
                  <label style="display: block; font-size: 11px; font-weight: 700; color: #0b192c; margin-bottom: 4px;">
                    What topic or experience would you like to post about?
                  </label>
                  <textarea class="copilot-input-field" id="post-topic-input" rows="2" placeholder="e.g. Scaling outbound SDR workflows, why most cold emails fail, closing our first 10 clients...">${g}</textarea>
                  <button class="copilot-btn-primary" id="generate-posts-btn" style="width: 100%; padding: 8px;">
                    ${y?`<span>⏳</span> Humanizing with Not-Ai...`:`<span>✍️</span> Generate 3 Human LinkedIn Posts`}
                  </button>
                </div>

                ${v.length>0?v.map(e=>`
                    <div class="copilot-sequence-step">
                      <div class="copilot-step-header">
                        <span class="copilot-step-tag">${e.title}</span>
                        <span class="copilot-notai-badge">Not-Ai: ${e.notAiScore}%</span>
                        <div class="copilot-step-btns">
                          <button class="copilot-insert-btn insert-post-btn" data-content="${encodeURIComponent(e.content)}">
                            📝 Insert into Post
                          </button>
                          <button class="copilot-step-btn copy-post-btn" data-content="${encodeURIComponent(e.content)}">
                            Copy
                          </button>
                        </div>
                      </div>
                      <p class="copilot-step-text">${e.content}</p>
                    </div>
                  `).join(``):`
                    <div style="text-align: center; padding: 20px 12px; color: #64748b; font-size: 11px;">
                      Enter a topic above to generate 3 source-grounded posts (Story, Playbook, Contrarian) free of generic AI buzzwords.
                    </div>
                  `}
              `:r===`comments`?`
                <!-- Not-Ai Comment Suggestions -->
                <div style="margin-bottom: 12px;">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                    <label style="font-size: 11px; font-weight: 700; color: #0b192c;">
                      Post text to reply to:
                    </label>
                    <button id="scrape-visible-post-btn" style="background: none; border: none; color: #1e3e62; font-size: 11px; font-weight: 700; cursor: pointer; text-decoration: underline;">
                      ⚡ Grab Post on Screen
                    </button>
                  </div>
                  <textarea class="copilot-input-field" id="comment-context-input" rows="2" placeholder="Paste post snippet or click 'Grab Post on Screen'...">${x}</textarea>
                  <button class="copilot-btn-primary" id="generate-comments-btn" style="width: 100%; padding: 8px;">
                    ${w?`<span>⏳</span> Crafting Thoughtful Replies...`:`<span>💬</span> Generate 3 Authentic Comments`}
                  </button>
                </div>

                ${S.length>0?S.map(e=>`
                    <div class="copilot-sequence-step">
                      <div class="copilot-step-header">
                        <span class="copilot-step-tag">${e.label}</span>
                        <span class="copilot-notai-badge">Not-Ai: ${e.notAiScore}%</span>
                        <div class="copilot-step-btns">
                          <button class="copilot-insert-btn insert-comment-btn" data-content="${encodeURIComponent(e.content)}">
                            💬 Insert Comment
                          </button>
                          <button class="copilot-step-btn copy-comment-btn" data-content="${encodeURIComponent(e.content)}">
                            Copy
                          </button>
                        </div>
                      </div>
                      <p class="copilot-step-text">${e.content}</p>
                    </div>
                  `).join(``):`
                    <div style="text-align: center; padding: 20px 12px; color: #64748b; font-size: 11px;">
                      Click <b>"Grab Post on Screen"</b> or paste any post to generate value-add comments that stand out from AI spam.
                    </div>
                  `}
              `:r===`osint`?`
                <div style="margin-bottom: 10px; font-size: 12px; color: #334155; line-height: 1.4;">
                  <b>1-Click Google OSINT Dorks (100% Free):</b><br/>
                  Locate indexed work emails, company PDFs, staff directories, and verified social handles without any paid credits:
                </div>
                ${(a?.osintDorks||[]).map(e=>`
                  <div class="copilot-dork-card">
                    <div class="copilot-dork-header">
                      <span class="copilot-dork-title">${e.title}</span>
                      <span class="copilot-dork-badge">${e.targetBadge}</span>
                    </div>
                    <div class="copilot-dork-desc">${e.description}</div>
                    <div class="copilot-dork-query-box">${e.query}</div>
                    <div class="copilot-dork-actions">
                      <button class="copilot-dork-btn" data-url="${encodeURIComponent(e.url)}">
                        🚀 Launch on Google
                      </button>
                      <button class="copilot-dork-copy-btn" data-query="${encodeURIComponent(e.query)}">
                        📋 Copy Query
                      </button>
                    </div>
                  </div>
                `).join(``)}
              `:s.length>0?s.map(e=>`
                <div class="copilot-sequence-step">
                  <div class="copilot-step-header">
                    <span class="copilot-step-tag">${e.label}</span>
                    <button class="copilot-step-btn copy-hook-btn" data-hook="${encodeURIComponent(e.message)}">Copy & Insert</button>
                  </div>
                  <p class="copilot-step-text">${e.message}</p>
                </div>
              `).join(``):`
                <div style="text-align: center; padding: 24px 12px; color: #94a3b8;">
                  <div style="font-size: 30px; margin-bottom: 6px;">✨</div>
                  <p style="margin: 0; font-size: 12px; color: #64748b;">
                    Click <b>"Generate Sequence"</b> to populate personalized connection hooks and angles.
                  </p>
                </div>
              `}
        </div>

        <!-- Footer -->
        <div class="copilot-footer">
          <span>Engine: Not-Ai 4.0 Humanizer • DNS DoH</span>
          <span style="font-weight: 700; color: #1e3e62;">Copilot v2.3</span>
        </div>
      </div>
    `,j.querySelector(`#copilot-close-btn`)?.addEventListener(`click`,()=>{n=!1,P()}),j.querySelector(`#tab-sequence`)?.addEventListener(`click`,()=>{r=`sequence`,F()}),j.querySelector(`#tab-posts`)?.addEventListener(`click`,()=>{r=`posts`,F()}),j.querySelector(`#tab-comments`)?.addEventListener(`click`,()=>{r=`comments`,F()}),j.querySelector(`#tab-osint`)?.addEventListener(`click`,()=>{r=`osint`,F()}),j.querySelector(`#tab-icebreakers`)?.addEventListener(`click`,()=>{r=`icebreakers`,F()}),j.querySelectorAll(`.copilot-subject-chip`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget;h=parseInt(t.getAttribute(`data-idx`)||`0`,10),F()})}),j.querySelector(`#quick-osint-btn`)?.addEventListener(`click`,()=>{r=`osint`;let e=a?.osintDorks?.[0];e&&C(e.url),F()}),j.querySelectorAll(`.copilot-dork-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget,n=decodeURIComponent(t.getAttribute(`data-url`)||``);n&&C(n)})}),j.querySelectorAll(`.copilot-dork-copy-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget,n=decodeURIComponent(t.getAttribute(`data-query`)||``);n&&(navigator.clipboard.writeText(n),t.innerText=`✓ Copied!`,setTimeout(()=>t.innerText=`📋 Copy Query`,2e3))})}),j.querySelector(`#generate-posts-btn`)?.addEventListener(`click`,async()=>{if(!y){g=j.querySelector(`#post-topic-input`)?.value||``,y=!0,F();try{let e=await _();v=await E(g,e)}catch(e){console.error(`Error generating posts:`,e)}finally{y=!1,F()}}}),j.querySelectorAll(`.insert-post-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget,n=decodeURIComponent(t.getAttribute(`data-content`)||``);n&&(navigator.clipboard.writeText(n),t.innerText=R(n)?`✓ Inserted!`:`✓ Copied!`,setTimeout(()=>t.innerText=`📝 Insert into Post`,2e3))})}),j.querySelectorAll(`.copy-post-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget,n=decodeURIComponent(t.getAttribute(`data-content`)||``);n&&(navigator.clipboard.writeText(n),t.innerText=`✓ Copied!`,setTimeout(()=>t.innerText=`Copy`,2e3))})}),j.querySelector(`#scrape-visible-post-btn`)?.addEventListener(`click`,()=>{let e=L();if(e){x=e;let t=j.querySelector(`#comment-context-input`);t&&(t.value=e)}}),j.querySelector(`#generate-comments-btn`)?.addEventListener(`click`,async()=>{if(!w){x=j.querySelector(`#comment-context-input`)?.value||``,w=!0,F();try{let e=await _();S=await D(x,e)}catch(e){console.error(`Error generating comments:`,e)}finally{w=!1,F()}}}),j.querySelectorAll(`.insert-comment-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget,n=decodeURIComponent(t.getAttribute(`data-content`)||``);n&&(navigator.clipboard.writeText(n),t.innerText=z(n)?`✓ Inserted!`:`✓ Copied!`,setTimeout(()=>t.innerText=`💬 Insert Comment`,2e3))})}),j.querySelectorAll(`.copy-comment-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget,n=decodeURIComponent(t.getAttribute(`data-content`)||``);n&&(navigator.clipboard.writeText(n),t.innerText=`✓ Copied!`,setTimeout(()=>t.innerText=`Copy`,2e3))})}),j.querySelector(`#extract-modal-btn`)?.addEventListener(`click`,async()=>{if(!m){m=!0,F();try{c=await T(e,u,!0)}catch(e){console.error(`Manual contact info check failed:`,e)}finally{m=!1,F()}}}),j.querySelector(`#copy-email-btn`)?.addEventListener(`click`,e=>{let t=e.currentTarget;a?.email&&(navigator.clipboard.writeText(a.email),t.innerText=`Copied!`,t.style.color=`#15803d`,setTimeout(()=>{t.innerText=`Copy`,t.style.color=`#1e3e62`},2e3))}),j.querySelector(`#copy-phone-btn`)?.addEventListener(`click`,e=>{let t=e.currentTarget;a?.phone&&(navigator.clipboard.writeText(a.phone),t.innerText=`Copied!`,t.style.color=`#15803d`,setTimeout(()=>{t.innerText=`Copy`,t.style.color=`#1e3e62`},2e3))}),j.querySelector(`#copilot-generate-btn`)?.addEventListener(`click`,async()=>{if(!p){p=!0,F();try{let t=await _();u=t;let[n,r]=await Promise.all([f(e,t),d(e,t)]);o=n,s=r}catch(e){console.error(`Error generating sequence:`,e)}finally{p=!1,F()}}}),j.querySelector(`#copilot-save-btn`)?.addEventListener(`click`,async t=>{let n=t.currentTarget;await b({name:e.name,headline:e.headline,company:e.company||`Unknown`,companyDomain:a?.domain,email:a?.email,phone:a?.phone,emailConfidence:a?.confidence,deliverabilityGrade:a?.deliverabilityGrade||`MX Verified`,sequence:o?{...o,touch3_email_subject:k}:void 0,profileUrl:e.profileUrl,selectedIcebreaker:o?.touch1_linkedin_connect||s[0]?.message}),n.classList.add(`copilot-btn-saved`),n.innerHTML=`<span>✓</span> Saved!`,setTimeout(()=>{n.classList.remove(`copilot-btn-saved`),n.innerHTML=`<span>💾</span> Save Lead`},2500)}),j.querySelector(`#copy-touch1`)?.addEventListener(`click`,e=>{if(l){navigator.clipboard.writeText(l.touch1_linkedin_connect),I(l.touch1_linkedin_connect);let t=e.currentTarget;t.innerText=`✓ Inserted!`,setTimeout(()=>t.innerText=`Copy & Insert`,2e3)}}),j.querySelector(`#copy-touch2`)?.addEventListener(`click`,e=>{if(l){navigator.clipboard.writeText(l.touch2_linkedin_followup);let t=e.currentTarget;t.innerText=`✓ Copied!`,setTimeout(()=>t.innerText=`Copy`,2e3)}}),j.querySelector(`#gmail-touch3`)?.addEventListener(`click`,()=>{if(l){let e=`https://mail.google.com/mail/?view=cm&fs=1&to=${a?.email||``}&su=${encodeURIComponent(k)}&body=${encodeURIComponent(l.touch3_email_body)}`;window.open(e,`_blank`)}}),j.querySelector(`#copy-touch3`)?.addEventListener(`click`,e=>{if(l){navigator.clipboard.writeText(`Subject: ${k}\n\n${l.touch3_email_body}`);let t=e.currentTarget;t.innerText=`✓ Copied!`,setTimeout(()=>t.innerText=`Copy`,2e3)}}),j.querySelector(`#copy-touch4`)?.addEventListener(`click`,e=>{if(l){navigator.clipboard.writeText(l.touch4_email_followup);let t=e.currentTarget;t.innerText=`✓ Copied!`,setTimeout(()=>t.innerText=`Copy`,2e3)}}),j.querySelectorAll(`.copy-hook-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget,n=decodeURIComponent(t.getAttribute(`data-hook`)||``);n&&(navigator.clipboard.writeText(n),I(n),t.innerText=`✓ Inserted!`,setTimeout(()=>t.innerText=`Copy & Insert`,2e3))})})}function I(e){let t=document.querySelector(`div.msg-form__contenteditable, textarea[name="message"], div[role="textbox"], textarea#custom-message`);t&&(t.tagName.toLowerCase()===`textarea`?t.value=e:(t.focus(),document.execCommand(`insertText`,!1,e)))}function L(){for(let e of[`.feed-shared-update-v2__description-wrapper .update-components-text`,`.feed-shared-update-v2 .feed-shared-text`,`.feed-shared-update-v2 .break-words`,`div[data-ad-preview="feed-update"] .feed-shared-text`,`main article .feed-shared-text`]){let t=document.querySelector(e)?.textContent?.trim();if(t&&t.length>20)return t.slice(0,450)}return``}function R(e){for(let t of[`div.share-creation-state__text-editor div.ql-editor`,`div.editor-content div.ql-editor`,`div[data-placeholder*="talk about"]`,`div.ql-editor[role="textbox"]`]){let n=document.querySelector(t);if(n)return n.focus(),document.execCommand(`selectAll`,!1),document.execCommand(`insertText`,!1,e),n.dispatchEvent(new Event(`input`,{bubbles:!0})),!0}return!1}function z(e){for(let t of[`div.comments-comment-box__editor div.ql-editor`,`form.comments-comment-box div.ql-editor`,`div.comments-comment-texteditor div.ql-editor`,`div[data-placeholder="Add a comment…"]`]){let n=document.querySelector(t);if(n)return n.focus(),document.execCommand(`selectAll`,!1),document.execCommand(`insertText`,!1,e),n.dispatchEvent(new Event(`input`,{bubbles:!0})),!0}return!1}async function B(){let e=window.location.href.split(`?`)[0].replace(/\/overlay\/.*$/,``).replace(/\/$/,``);if(e===a&&i)return;a=e;let n=t();n?(i=n,o=null,s=[],h=0,c=await T(n,u,!1)):(i=null,c=null)}function V(){if(!document.body){setTimeout(V,50);return}document.body.appendChild(O),P();let e=M(window.location.pathname);setInterval(()=>{let t=M(window.location.pathname);t!==e&&(e=t,B(),n&&F())},1500),console.log(`⚡ LinkedIn Outreach Copilot + Not-Ai Humanizer ready.`)}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,V):V()})()})();
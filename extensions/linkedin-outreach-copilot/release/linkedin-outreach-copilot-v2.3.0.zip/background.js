chrome.runtime.onInstalled.addListener((e) => {
	e.reason === "install" && (console.log("LinkedIn Outreach Copilot installed successfully."), chrome.storage.sync.set({ settings: {
		aiProvider: "gemini",
		dailyQuota: 5,
		usedToday: 0,
		lastResetDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
		isPro: !1
	} }));
}), chrome.runtime.onMessage.addListener((e, t, n) => (e.type === "PING" && n({ status: "PONG" }), !0));
